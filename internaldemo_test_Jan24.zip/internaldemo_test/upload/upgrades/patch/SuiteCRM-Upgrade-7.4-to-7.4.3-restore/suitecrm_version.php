<?php
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$suitecrm_version      = '7.4 Beta';
$suitecrm_timestamp    = '2015-10-01 17:00pm';
