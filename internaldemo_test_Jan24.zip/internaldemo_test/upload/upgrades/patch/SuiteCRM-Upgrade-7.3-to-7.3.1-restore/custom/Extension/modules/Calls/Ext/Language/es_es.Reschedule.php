<?php
$mod_strings = array_merge($mod_strings, 
	array (
		'LBL_RESCHEDULE' => 'Replanificar',
    		'LBL_RESCHEDULE_COUNT' => 'Intentos de llamar',
    		'LBL_RESCHEDULE_DATE' => 'Fecha',
    		'LBL_RESCHEDULE_REASON' => 'Razón',
    		'LBL_RESCHEDULE_ERROR1' => 'Por favor, seleccione una fecha válida',
    		'LBL_RESCHEDULE_ERROR2' => 'Por favor seleccione una razón',
    		'LBL_RESCHEDULE_PANEL' => 'Replanificación',
    		'LBL_RESCHEDULE_HISTORY' => 'Historial de Intentos de Llamada'
	),
);
